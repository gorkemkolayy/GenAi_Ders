// --- ÇOKLU DİL DESTEĞİ VE VERİLER ---
const translations = {
    tr: {
        // Navigasyon
        nav_home: "Ana Sayfa",
        nav_about: "Hakkımda",
        nav_skills: "Yetenekler",
        nav_contact: "İletişim",
        
        // Ana Sayfa (Hero)
        status_badge: "Yeni Projelere Açık",
        hero_greeting: "Merhaba, ben",
        hero_desc: "Modern web teknolojileri ve sistem programlama tutkusuyla kod yazıyorum.",
        hero_btn: "İletişime Geç",
        
        // Hakkımda Sayfası
        section_about: "Hakkımda & Eğitim",
        about_text: "Ben Görkem. Samsun'un Bafra ilçesinde doğdum ve yaşamımı Samsun'un Canik ilçesinde sürdürüyorum. Şu anda Sinop'un Ayancık ilçesinde üniversite eğitimime devam etmekteyim. İş hayatı olarak aile şirketimizde 7 yılı aşkın süredir çalışıyorum. Çocukluğumda başlayan iş hayatı deneyimimi üniversite bittikten sonra da profesyonel olarak devam ettireceğim.",
        time_now: "2017 - Günümüz",
        exp_title: "Aile Şirketi",
        exp_desc: "7 yılı aşkın süredir aktif iş hayatı deneyimi, operasyonel süreçler ve yönetim tecrübesi.",
        time_uni: "Üniversite",
        uni_title: "Sinop Ayancık MYO",
        uni_desc: "Bilgisayar Programcılığı / İnternet ve Ağ Teknolojileri",
        time_hs: "Lise",
        hs_title: "Samsun Canik Mesleki ve Teknik Anadolu Lisesi",
        hs_desc: "Bilişim Teknolojileri Alanı",
        
        // Yetenekler Sayfası
        section_skills: "Teknik Yetenekler",
        skill_csharp: "Kurumsal mimariler ve masaüstü uygulamaları.",
        skill_cpp: "Yüksek performanslı sistem programlama.",
        skill_node: "Ölçeklenebilir backend servisleri.",
        skill_web: "Modern ve duyarlı arayüz tasarımı.",
        
        // İletişim Sayfası
        section_contact: "İletişime Geç",
        contact_text: "Yeni projeler, freelance işler veya sadece teknoloji üzerine sohbet etmek için buradayım.",
        contact_btn: "Bana Mail Gönder",
        
        // Footer & Chatbot
        footer_text: "Tasarım ve Kodlama ❤️ ile yapıldı.",
        chat_header: "GK Asistan",
        chat_status: "Çevrimiçi",
        chat_welcome: "Merhaba! Ben Görkem'in sanal asistanıyım. Sana nasıl yardımcı olabilirim?",
        chat_placeholder: "Mesaj yazın..."
    },
    en: {
        // Navigation
        nav_home: "Home",
        nav_about: "About",
        nav_skills: "Skills",
        nav_contact: "Contact",
        
        // Home (Hero)
        status_badge: "Open to Work",
        hero_greeting: "Hello, I'm",
        hero_desc: "I code with a passion for modern web technologies and system programming.",
        hero_btn: "Contact Me",
        
        // About Page
        section_about: "About & Education",
        about_text: "I'm Görkem. I was born in Bafra, Samsun and I live in Canik, Samsun. I am currently continuing my university education in Ayancık, Sinop. I have been working in our family company for over 7 years. I will continue my business life experience, which started in my childhood, professionally after graduating from university.",
        time_now: "2017 - Present",
        exp_title: "Family Business",
        exp_desc: "Over 7 years of active business experience, operational processes and management experience.",
        time_uni: "University",
        uni_title: "Sinop Ayancik VHS",
        uni_desc: "Computer Programming / Internet and Network Technologies",
        time_hs: "High School",
        hs_title: "Samsun Canik Vocational and Technical Anatolian High School",
        hs_desc: "Information Technologies Area",
        
        // Skills Page
        section_skills: "Technical Skills",
        skill_csharp: "Enterprise architectures and desktop applications.",
        skill_cpp: "High-performance system programming.",
        skill_node: "Scalable backend services.",
        skill_web: "Modern and responsive interface design.",
        
        // Contact Page
        section_contact: "Get in Touch",
        contact_text: "I'm here for new projects, freelance work or just to chat about technology.",
        contact_btn: "Send Me Email",
        
        // Footer & Chatbot
        footer_text: "Designed and Coded with ❤️.",
        chat_header: "GK Assistant",
        chat_status: "Online",
        chat_welcome: "Hello! I am Görkem's virtual assistant. How can I help you?",
        chat_placeholder: "Type a message..."
    }
};

// Daktilo Efekti için Metinler
const typewriterTexts = {
    tr: ["C++ Developer", "C# & .NET Uzmanı", "Full Stack Developer", "Node.js Meraklısı"],
    en: ["C++ Developer", "C# & .NET Specialist", "Full Stack Developer", "Node.js Enthusiast"]
};

// --- DİL YÖNETİMİ ---
// Tarayıcı hafızasından dili al, yoksa Türkçe başla
let currentLang = localStorage.getItem('selectedLang') || 'tr';

function updateContent() {
    // Dil butonlarını güncelle
    const langBtn = document.getElementById('lang-text');
    const mobileLangBtn = document.getElementById('mobile-lang-text');
    if (langBtn) langBtn.innerText = currentLang === 'tr' ? 'TR' : 'EN';
    if (mobileLangBtn) mobileLangBtn.innerText = currentLang === 'tr' ? 'TR' : 'EN';

    // Sayfadaki tüm çevrilebilir alanları güncelle
    document.querySelectorAll('[data-lang]').forEach(el => {
        const key = el.getAttribute('data-lang');
        if (translations[currentLang][key]) {
            el.innerText = translations[currentLang][key];
        }
    });

    // Input placeholderlarını güncelle
    document.querySelectorAll('[data-lang-placeholder]').forEach(el => {
        const key = el.getAttribute('data-lang-placeholder');
        if (translations[currentLang][key]) {
            el.placeholder = translations[currentLang][key];
        }
    });
}

function toggleLanguage() {
    // Dili değiştir ve kaydet
    currentLang = currentLang === 'tr' ? 'en' : 'tr';
    localStorage.setItem('selectedLang', currentLang);
    
    updateContent();
    
    // Eğer ana sayfadaysak daktilo efektini sıfırla
    if (document.getElementById('typewriter')) {
        initTypewriter(); 
    }
}

// --- DAKTİLO EFEKTİ (Sadece Ana Sayfa için) ---
let typewriterTimeout;
function initTypewriter() {
    clearTimeout(typewriterTimeout);
    const textElement = document.getElementById('typewriter');
    
    // Eğer sayfada typewriter elementi yoksa (örn: iletişim sayfası) fonksiyonu durdur
    if (!textElement) return;

    const texts = typewriterTexts[currentLang];
    let count = 0;
    let index = 0;
    let currentText = "";
    let letter = "";

    function type() {
        if (count === texts.length) {
            count = 0;
        }
        currentText = texts[count];
        letter = currentText.slice(0, ++index);

        textElement.textContent = letter;

        if (letter.length === currentText.length) {
            typewriterTimeout = setTimeout(() => {
                count++;
                index = 0;
                type();
            }, 2000); // Kelime bitince bekleme süresi
        } else {
            typewriterTimeout = setTimeout(type, 100); // Yazma hızı
        }
    }
    
    type(); // Başlat
}

// --- MOUSE HAREKETİ VE EFEKTLER ---
document.addEventListener('mousemove', (e) => {
    const x = e.clientX;
    const y = e.clientY;

    const cursorGlow = document.querySelector('.cursor-glow');
    if (cursorGlow) {
        cursorGlow.style.left = `${x}px`;
        cursorGlow.style.top = `${y}px`;
        // CSS transform ile merkezleme yapılıyor
        cursorGlow.style.transform = `translate(-50%, -50%)`;
    }

    document.querySelectorAll('.bg-glow').forEach(glow => {
        const speed = glow.getAttribute('data-speed') || 2;
        const xPos = (window.innerWidth - x * speed) / 100;
        const yPos = (window.innerHeight - y * speed) / 100;
        glow.style.transform = `translate(${xPos}px, ${yPos}px)`;
    });
});

// --- MOBİL MENÜ ---
function toggleMobileMenu() {
    const hamburger = document.querySelector('.hamburger');
    const mobileMenu = document.getElementById('mobile-menu');
    
    if (hamburger && mobileMenu) {
        hamburger.classList.toggle('active');
        mobileMenu.classList.toggle('active');
    }
}

// --- CHATBOT MANTIĞI ---
function toggleChat() {
    const chatBox = document.getElementById('chat-box');
    if (chatBox) {
        chatBox.classList.toggle('active');
    }
}

function sendMessage() {
    const input = document.getElementById('chat-input');
    const chatBody = document.getElementById('chat-body');
    
    if (!input || !chatBody) return;

    const message = input.value.trim();

    if (message) {
        // Kullanıcı Mesajı
        const userDiv = document.createElement('div');
        userDiv.className = 'message user-msg';
        userDiv.innerText = message;
        chatBody.appendChild(userDiv);
        
        input.value = '';
        chatBody.scrollTop = chatBody.scrollHeight;

        // Bot Cevabı (Simülasyon)
        setTimeout(() => {
            const botDiv = document.createElement('div');
            botDiv.className = 'message bot-msg';
            botDiv.innerText = getBotResponse(message);
            chatBody.appendChild(botDiv);
            chatBody.scrollTop = chatBody.scrollHeight;
        }, 1000);
    }
}

function getBotResponse(input) {
    input = input.toLowerCase();
    const isTr = currentLang === 'tr';

    // Selamlaşma
    if (input.includes('merhaba') || input.includes('selam') || input.includes('hi') || input.includes('hello')) {
        return isTr 
            ? "Merhaba! Projelerim, yeteneklerim veya eğitimim hakkında sorular sorabilirsin." 
            : "Hello! You can ask about my projects, skills, or education.";
    } 
    // İletişim / Mail
    else if (input.includes('iletişim') || input.includes('contact') || input.includes('mail') || input.includes('email') || input.includes('ulaş')) {
        return isTr 
            ? "Bana en hızlı iletisim@gorkemkolay.com adresinden veya sosyal medya linklerinden ulaşabilirsin." 
            : "You can reach me fastest at iletisim@gorkemkolay.com or via the social media links.";
    } 
    // Yetenekler / Skills
    else if (input.includes('yetenek') || input.includes('skill') || input.includes('bilgi') || input.includes('know')) {
        return isTr 
            ? "C#, .NET, C++ ve Node.js başta olmak üzere modern web teknolojilerinde uzmanım." 
            : "I specialize in C#, .NET, C++, and Node.js, along with modern web technologies.";
    }
    // Eğitim / Okul
    else if (input.includes('eğitim') || input.includes('okul') || input.includes('üniversite') || input.includes('education') || input.includes('university')) {
        return isTr
            ? "Sinop Ayancık MYO'da Bilgisayar Programcılığı okuyorum. Lise eğitimimi Samsun Canik MTAL'de tamamladım."
            : "I study Computer Programming at Sinop Ayancik VHS. I completed high school at Samsun Canik Vocational High School.";
    }
    // İş / Freelance
    else if (input.includes('iş') || input.includes('freelance') || input.includes('proje') || input.includes('work') || input.includes('job')) {
        return isTr
            ? "Şu an yeni projelere ve iş tekliflerine açığım! Detayları konuşmak için bana mail atabilirsin."
            : "I am currently open to new projects and job offers! You can email me to discuss details.";
    }
    // Kimsin
    else if (input.includes('kimsin') || input.includes('görkem') || input.includes('who') || input.includes('about')) {
        return isTr
            ? "Ben Görkem, Samsun'da yaşayan ve yazılım geliştirmeye tutkulu bir Full Stack Geliştiriciyim."
            : "I'm Görkem, a Full Stack Developer based in Samsun, passionate about software development.";
    }
    // Teşekkür
    else if (input.includes('teşekkür') || input.includes('sağ ol') || input.includes('thanks')) {
        return isTr
            ? "Rica ederim! Başka bir sorun varsa buradayım."
            : "You're welcome! I'm here if you have any other questions.";
    }
    // Anlaşılamadı
    else {
        return isTr 
            ? "Bunu tam anlayamadım. 'İletişim', 'Eğitim' veya 'Yetenekler' gibi anahtar kelimeler deneyebilirsin." 
            : "I didn't quite catch that. Try keywords like 'Contact', 'Education', or 'Skills'.";
    }
}

// --- BAŞLANGIÇ AYARLARI ---
window.addEventListener('DOMContentLoaded', () => {
    // 1. İçeriği güncelle
    updateContent();
    
    // 2. Eğer varsa daktilo efektini başlat
    initTypewriter();

    // 3. Loader'ı gizle
    const loader = document.getElementById('loader');
    if (loader) {
        setTimeout(() => {
            loader.style.opacity = '0';
            loader.style.visibility = 'hidden';
            loader.style.pointerEvents = 'none';
        }, 1500);
    }

    // 4. Chatbot Enter tuşu dinleyicisi
    const chatInput = document.getElementById('chat-input');
    if (chatInput) {
        chatInput.addEventListener('keypress', function (e) {
            if (e.key === 'Enter') {
                sendMessage();
            }
        });
    }
    
    // 5. Scroll Reveal (Sayfa kaydırma animasyonları)
    window.addEventListener('scroll', reveal);
});

function reveal(){
    var reveals = document.querySelectorAll('.skill-card, .contact-container, .timeline-item, .project-card');

    for(var i = 0; i < reveals.length; i++){
        var windowheight = window.innerHeight;
        var revealtop = reveals[i].getBoundingClientRect().top;
        var revealpoint = 150;

        if(revealtop < windowheight - revealpoint){
            reveals[i].style.opacity = '1';
            reveals[i].style.transform = 'translateY(0)';
        }
    }
}

// Reveal elementlerinin başlangıç stilini ayarla (JS yüklendiğinde)
document.querySelectorAll('.skill-card, .contact-container, .timeline-item, .project-card').forEach(el => {
    el.style.opacity = '0';
    el.style.transform = 'translateY(20px)';
    el.style.transition = 'all 0.6s ease-out';
});